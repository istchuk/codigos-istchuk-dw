let condicao1 = true
let condicao2 = false
let condicao3 = true

console.log("1")
console.log("2")

if (condicao1 == true) {
    if (condicao2 == true) {
       console.log("C") 
    }
    else {
        console.log("D")
    }
}
else {
    if (condicao3 == true){
    console.log("A")
    }
    else{
        console.log("B")
    }
}

console.log("3")
console.log("4")