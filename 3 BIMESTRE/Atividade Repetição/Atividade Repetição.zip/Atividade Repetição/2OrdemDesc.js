function ordemDesc(numero){
    i = 1

    while (i <= numero){
        console.log(numero)
        numero -= 1
    }
}

ordemDesc(13)