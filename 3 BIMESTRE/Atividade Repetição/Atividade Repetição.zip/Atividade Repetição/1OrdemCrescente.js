function ordemCrescente(numero){
    i = 1

    while (i <= numero){
        console.log(i)
        i += 1
    }
}

ordemCrescente(13)